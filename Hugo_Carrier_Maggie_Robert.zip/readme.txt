# IFT3913-A-A22-TP3
Hugo Carrier: 20197563
Maggie Robert: 20182443

Lien vers le repositorie: https://github.com/3Pi1416/IFT3913-A-A22-TP3

Tous les calculations ont été faites avec Excel.